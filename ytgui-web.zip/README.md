# YTGUI Web — Proof of Concept

Migrasi dari TUI (Textual) ke Web (FastAPI + SSE + Vanilla JS).
Server berjalan di Termux, diakses dari browser di `http://localhost:8000`.

---

## Arsitektur

```
Browser (Chrome)  ←──HTTP/SSE──→  FastAPI (server.py)
                                        │
                          ┌─────────────┼─────────────┐
                          ↓             ↓              ↓
                    EventBus      AppState       engine/
                    (pub/sub)     (shared)    mpv, ytdlp,
                                            cache, lyrics
```

**Yang TIDAK berubah** dari versi TUI:
- `core/state.py`       → AppState & TrackInfo (sama persis)
- `core/event_bus.py`   → EventBus (sama persis)
- `engine/`             → mpv_controller, ytdlp_client, playback_controller (sama persis)
- `cache/`              → db, resolver (sama persis)
- `integrations/`       → lyrics, sponsorblock (sama persis)

**Yang berubah**:
- `tui/` → **dihapus** (diganti `server.py` + `static/index.html`)
- `main.py` → diganti `server.py` (FastAPI lifespan = startup/shutdown logic yang sama)

---

## Setup di Termux

```bash
# 1. Install system dependencies
pkg update
pkg install python mpv

# 2. Clone/copy project
# (copy folder ytgui-web ke Termux)

# 3. Install Python dependencies
pip install -r requirements.txt

# 4. Jalankan server
uvicorn server:app --host 0.0.0.0 --port 8000

# 5. Buka di Chrome
# http://localhost:8000
```

---

## Kenapa ini REALISTIS

### ✅ Keuntungan migrasi

1. **Engine tidak perlu diubah** — `engine/`, `core/`, `cache/`, `integrations/` 100% reused.
   Ini adalah 90% dari logic aplikasi.

2. **Async-native** — Codebase sudah pakai `asyncio` penuh. FastAPI juga async,
   jadi tidak ada konflik threading / event loop.

3. **EventBus → SSE** — EventBus sudah pub/sub. Kita hanya tambahkan
   bridge: setiap event bus di-forward ke SSE queue → browser update real-time.

4. **Textual dihapus total** — Satu-satunya dependency TUI (`textual`, `rich`)
   tidak ada di requirements web. Tidak ada kode engine yang import textual.

5. **MPV tetap jalan di background** — MPV dijalankan sebagai subprocess,
   bukan tergantung pada terminal. Cocok untuk Termux (audio tetap bunyi
   meski browser di foreground).

### ⚠️ Yang perlu diperhatikan

1. **mpv harus terinstall** → `pkg install mpv`
2. **SSE perlu koneksi stabil** → di localhost tidak masalah
3. **yt-dlp bisa lambat** saat search pertama (wajar, bukan bug)
4. **Lyrics sync** → sudah di-bridge via SSE, tapi timing mungkin perlu
   fine-tuning jika ada latency SSE

---

## Endpoint API

| Method | Path | Keterangan |
|--------|------|------------|
| GET | `/` | Frontend HTML |
| GET | `/api/state` | Snapshot state saat ini |
| GET | `/api/events` | SSE stream real-time |
| POST | `/api/search` | `{"query": "...", "max_results": 10}` |
| POST | `/api/play` | `{video_id, title, artist, duration, thumbnail}` |
| POST | `/api/pause` | Toggle pause/play |
| POST | `/api/next` | Lagu berikutnya |
| POST | `/api/prev` | Lagu sebelumnya |
| POST | `/api/stop` | Stop & clear queue |
| POST | `/api/seek` | `{"position": 42.5}` |
| POST | `/api/volume/up` | Volume naik |
| POST | `/api/volume/down` | Volume turun |
| POST | `/api/queue/add` | Tambah ke queue |
| DELETE | `/api/queue/{index}` | Hapus dari queue |
| POST | `/api/queue/select/{index}` | Play lagu di posisi index |
| POST | `/api/mode/QUEUE` | Switch ke Queue Mode |
| POST | `/api/mode/RADIO` | Switch ke Radio Mode |
| POST | `/api/radio/randomize` | Randomize radio |
