"""
YTGUI Web - FastAPI server (Proof of Concept)
Menggantikan tui/app.py dengan web server + REST API + SSE untuk realtime update.

Run: uvicorn server:app --host 0.0.0.0 --port 8000 --reload
"""

import asyncio
import json
import logging
import stat
import sys
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import aiohttp
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from core.state import AppState, PlayerStatus, PlaybackMode, TrackInfo
from core.event_bus import (
    bus,
    CMD_PLAY_TRACK, CMD_TOGGLE_PAUSE, CMD_NEXT, CMD_PREV, CMD_STOP,
    CMD_SEEK, CMD_VOLUME_UP, CMD_VOLUME_DOWN, CMD_DOWNLOAD,
    CMD_SET_MODE, CMD_QUEUE_ADD, CMD_QUEUE_REMOVE, CMD_QUEUE_SELECT,
    CMD_RADIO_RANDOMIZE, CMD_QUIT,
    TRACK_STARTED, TRACK_ENDED, TRACK_PROGRESS, QUEUE_UPDATED, LYRICS_UPDATED,
)
from cache.db import Database
from cache.resolver import CacheResolver
from engine.mpv_controller import MpvController
from engine.ytdlp_client import YtDlpClient
from engine.queue_mode import QueueMode
from engine.radio_mode import RadioMode
from engine.volume_service import VolumeService
from engine.download_manager import DownloadManager
from engine.playback_controller import PlaybackController
from integrations.sponsorblock import SponsorBlockHandler
from integrations.lyrics import LyricsFetcher
from config import BASE_DIR

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

# ── Global App State ─────────────────────────────────────────────────────────
state = AppState()
db: Database = None
ytdlp: YtDlpClient = None
mpv: MpvController = None
controller: PlaybackController = None
http_session: aiohttp.ClientSession = None

# SSE subscribers - setiap browser tab punya asyncio.Queue sendiri
_sse_queues: list[asyncio.Queue] = []

async def _broadcast(event_type: str, data: dict):
    """Push event ke semua SSE subscribers."""
    msg = {"type": event_type, "data": data}
    for q in list(_sse_queues):
        await q.put(msg)

def _state_snapshot() -> dict:
    """Serialisasi AppState ke dict untuk dikirim ke client."""
    track = None
    if state.current_track:
        t = state.current_track
        track = {
            "video_id": t.video_id,
            "title": t.title,
            "artist": t.artist,
            "duration": t.duration,
            "thumbnail": t.thumbnail,
        }
    return {
        "status": state.status.name,
        "mode": state.playback_mode.name,
        "current_track": track,
        "position": state.position,
        "volume": state.volume,
        "is_online": state.is_online,
        "error_msg": state.error_msg,
        "queue": [
            {"video_id": t.video_id, "title": t.title, "artist": t.artist, "duration": t.duration}
            for t in list(state.queue)
        ],
        "lyrics": {
            "lines": state.lyrics_lines,
            "index": state.lyrics_index,
        } if state.lyrics_lines else None,
    }

# ── Wire event bus → SSE ──────────────────────────────────────────────────────
async def _on_track_started(track: TrackInfo):
    await _broadcast("track_started", _state_snapshot())

async def _on_track_ended(data):
    await _broadcast("track_ended", _state_snapshot())

async def _on_progress(pos: float):
    # Throttle: hanya kirim setiap 1 detik agar tidak flood
    await _broadcast("progress", {"position": pos, "status": state.status.name})

async def _on_queue_updated(_data=None):
    await _broadcast("queue_updated", _state_snapshot())

async def _on_lyrics_updated(_data=None):
    lines = state.lyrics_lines
    idx = state.lyrics_index
    current_line = lines[idx][1] if lines and 0 <= idx < len(lines) else ""
    await _broadcast("lyrics_updated", {"index": idx, "current_line": current_line})

bus.subscribe(TRACK_STARTED, _on_track_started)
bus.subscribe(TRACK_ENDED, _on_track_ended)
bus.subscribe(TRACK_PROGRESS, _on_progress)
bus.subscribe(QUEUE_UPDATED, _on_queue_updated)
bus.subscribe(LYRICS_UPDATED, _on_lyrics_updated)

# ── Lifespan (startup/shutdown) ───────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global db, ytdlp, mpv, controller, http_session

    db = Database()
    await db.init()

    ytdlp = YtDlpClient()
    mpv = MpvController()

    try:
        await mpv.connect()
    except Exception as e:
        logger.error(f"mpv tidak tersedia: {e}")
        state.error_msg = "MPV tidak ditemukan. Install: pkg install mpv"
        state.status = PlayerStatus.ERROR

    http_session = aiohttp.ClientSession()
    resolver = CacheResolver(db, ytdlp)
    sponsorblock = SponsorBlockHandler(mpv, state=state, session=http_session)
    lyrics_fetcher = LyricsFetcher(state, session=http_session)
    queue_mode = QueueMode()
    radio_mode = RadioMode(ytdlp, state)
    volume_service = VolumeService(bus, mpv, state)
    download_manager = DownloadManager(bus, state, ytdlp)
    controller = PlaybackController(
        bus, state, mpv, resolver, sponsorblock, lyrics_fetcher, queue_mode, radio_mode
    )

    async def connectivity_check():
        while True:
            try:
                async with http_session.get(
                    "https://connectivitycheck.gstatic.com/generate_204",
                    timeout=aiohttp.ClientTimeout(total=3)
                ) as r:
                    state.is_online = (r.status == 204)
            except Exception:
                state.is_online = False
            await asyncio.sleep(30)

    asyncio.create_task(connectivity_check())

    yield  # server running

    # Shutdown
    lyrics_fetcher.cleanup()
    sponsorblock.cleanup()
    ytdlp.cancel_download()
    await http_session.close()
    await mpv.close()
    await db.close()

# ── FastAPI App ───────────────────────────────────────────────────────────────
app = FastAPI(title="YTGUI Web", lifespan=lifespan)

# ── Pydantic Schemas ──────────────────────────────────────────────────────────
class SearchRequest(BaseModel):
    query: str
    max_results: int = 10

class PlayRequest(BaseModel):
    video_id: str
    title: str
    artist: str
    duration: int
    thumbnail: str | None = None

class SeekRequest(BaseModel):
    position: float

class QueueAddRequest(BaseModel):
    video_id: str
    title: str
    artist: str
    duration: int
    thumbnail: str | None = None

# ── REST Endpoints ────────────────────────────────────────────────────────────

@app.get("/api/state")
async def get_state():
    return _state_snapshot()

@app.post("/api/search")
async def search(req: SearchRequest):
    if not state.is_online:
        raise HTTPException(503, "Offline")
    tracks = await ytdlp.search(req.query, max_results=req.max_results)
    return [
        {
            "video_id": t.video_id,
            "title": t.title,
            "artist": t.artist,
            "duration": t.duration,
            "thumbnail": t.thumbnail,
        }
        for t in tracks
    ]

@app.post("/api/play")
async def play(req: PlayRequest):
    track = TrackInfo(
        video_id=req.video_id,
        title=req.title,
        artist=req.artist,
        duration=req.duration,
        thumbnail=req.thumbnail,
    )
    await bus.publish(CMD_PLAY_TRACK, track)
    return {"ok": True}

@app.post("/api/pause")
async def toggle_pause():
    await bus.publish(CMD_TOGGLE_PAUSE)
    return {"ok": True}

@app.post("/api/next")
async def next_track():
    await bus.publish(CMD_NEXT)
    return {"ok": True}

@app.post("/api/prev")
async def prev_track():
    await bus.publish(CMD_PREV)
    return {"ok": True}

@app.post("/api/stop")
async def stop():
    await bus.publish(CMD_STOP)
    return {"ok": True}

@app.post("/api/seek")
async def seek(req: SeekRequest):
    await bus.publish(CMD_SEEK, req.position)
    return {"ok": True}

@app.post("/api/volume/up")
async def volume_up():
    await bus.publish(CMD_VOLUME_UP)
    return {"ok": True}

@app.post("/api/volume/down")
async def volume_down():
    await bus.publish(CMD_VOLUME_DOWN)
    return {"ok": True}

@app.post("/api/queue/add")
async def queue_add(req: QueueAddRequest):
    track = TrackInfo(
        video_id=req.video_id,
        title=req.title,
        artist=req.artist,
        duration=req.duration,
        thumbnail=req.thumbnail,
    )
    await bus.publish(CMD_QUEUE_ADD, track)
    return {"ok": True}

@app.delete("/api/queue/{index}")
async def queue_remove(index: int):
    await bus.publish(CMD_QUEUE_REMOVE, index)
    return {"ok": True}

@app.post("/api/queue/select/{index}")
async def queue_select(index: int):
    await bus.publish(CMD_QUEUE_SELECT, index)
    return {"ok": True}

@app.post("/api/mode/{mode}")
async def set_mode(mode: str):
    if mode == "RADIO":
        await bus.publish(CMD_SET_MODE, PlaybackMode.RADIO)
    elif mode == "QUEUE":
        await bus.publish(CMD_SET_MODE, PlaybackMode.QUEUE)
    else:
        raise HTTPException(400, "mode harus RADIO atau QUEUE")
    return {"ok": True}

@app.post("/api/radio/randomize")
async def radio_randomize():
    await bus.publish(CMD_RADIO_RANDOMIZE)
    return {"ok": True}

# ── SSE Endpoint ──────────────────────────────────────────────────────────────
@app.get("/api/events")
async def sse_stream():
    """
    Server-Sent Events stream. Browser subscribe ke sini untuk realtime update.
    Setiap event berformat: data: {json}\n\n
    """
    q: asyncio.Queue = asyncio.Queue()
    _sse_queues.append(q)

    async def generate() -> AsyncGenerator[str, None]:
        # Kirim state awal saat connect
        snapshot = _state_snapshot()
        yield f"data: {json.dumps({'type': 'init', 'data': snapshot})}\n\n"
        try:
            while True:
                try:
                    msg = await asyncio.wait_for(q.get(), timeout=25.0)
                    yield f"data: {json.dumps(msg)}\n\n"
                except asyncio.TimeoutError:
                    # Heartbeat agar koneksi tidak di-drop
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            _sse_queues.remove(q)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
            "Connection": "keep-alive",
        },
    )

# ── Frontend (Single HTML) ────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index():
    with open(BASE_DIR / "static" / "index.html", encoding="utf-8") as f:
        return f.read()
