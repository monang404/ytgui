# tui panels module
