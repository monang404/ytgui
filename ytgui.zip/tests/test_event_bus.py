import pytest
import asyncio
from unittest.mock import Mock
from core.event_bus import EventBus

@pytest.fixture
def bus():
    return EventBus()

@pytest.mark.asyncio
async def test_event_bus_strong_reference(bus):
    mock_handler = Mock()
    bus.subscribe("test.event", mock_handler)
    await bus.publish("test.event", "data")
    mock_handler.assert_called_once_with("data")

@pytest.mark.asyncio
async def test_event_bus_weak_reference(bus):
    class Subscriber:
        def __init__(self):
            self.called = False

        def handle(self, data):
            self.called = True

    sub = Subscriber()
    bus.subscribe("test.event", sub.handle)
    
    # Harus dipanggil jika object masih hidup
    await bus.publish("test.event", "data1")
    assert sub.called

    # Hapus object (simulasi garbage collection)
    del sub
    import gc
    gc.collect()

    # Publish lagi, tidak boleh ada error meskipun object sudah mati
    await bus.publish("test.event", "data2")

@pytest.mark.asyncio
async def test_event_bus_unsubscribe(bus):
    mock_handler = Mock()
    bus.subscribe("test.event", mock_handler)
    bus.unsubscribe("test.event", mock_handler)
    
    await bus.publish("test.event", "data")
    mock_handler.assert_not_called()

@pytest.mark.asyncio
async def test_event_bus_error_isolation(bus):
    def failing_handler(data):
        raise Exception("Oops")

    success_handler = Mock()

    bus.subscribe("test.event", failing_handler)
    bus.subscribe("test.event", success_handler)

    # Meskipun failing_handler error, success_handler harus tetap dipanggil
    await bus.publish("test.event", "data")
    success_handler.assert_called_once_with("data")
